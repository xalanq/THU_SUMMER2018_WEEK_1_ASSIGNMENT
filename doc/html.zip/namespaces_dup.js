var namespaces_dup =
[
    [ "Core", "d3/d7a/namespaceCore.html", null ],
    [ "Ui", "db/d3c/namespaceUi.html", null ]
];