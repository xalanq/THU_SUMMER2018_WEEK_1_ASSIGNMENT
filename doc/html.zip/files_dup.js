var files_dup =
[
    [ "Core.cpp", "d6/d27/Core_8cpp.html", "d6/d27/Core_8cpp" ],
    [ "Core.h", "d6/dd7/Core_8h.html", "d6/dd7/Core_8h" ],
    [ "main.cpp", "df/d0a/main_8cpp.html", "df/d0a/main_8cpp" ],
    [ "MainWidget.cpp", "d9/db7/MainWidget_8cpp.html", null ],
    [ "MainWidget.h", "da/d1e/MainWidget_8h.html", [
      [ "MainWidget", "d9/d73/classMainWidget.html", "d9/d73/classMainWidget" ],
      [ "Pipe", "dc/d2e/structMainWidget_1_1Pipe.html", "dc/d2e/structMainWidget_1_1Pipe" ],
      [ "Node", "da/d47/structMainWidget_1_1Node.html", "da/d47/structMainWidget_1_1Node" ]
    ] ],
    [ "MainWindow.cpp", "d3/db7/MainWindow_8cpp.html", null ],
    [ "MainWindow.h", "da/d9c/MainWindow_8h.html", [
      [ "MainWindow", "d6/d1a/classMainWindow.html", "d6/d1a/classMainWindow" ]
    ] ],
    [ "NewDialog.cpp", "d6/dda/NewDialog_8cpp.html", null ],
    [ "NewDialog.h", "d4/d87/NewDialog_8h.html", [
      [ "NewDialog", "d3/dcc/classNewDialog.html", "d3/dcc/classNewDialog" ]
    ] ],
    [ "PanelWidget.cpp", "d1/d07/PanelWidget_8cpp.html", null ],
    [ "PanelWidget.h", "de/d42/PanelWidget_8h.html", [
      [ "PanelWidget", "d3/d3b/classPanelWidget.html", "d3/d3b/classPanelWidget" ]
    ] ],
    [ "PipeWidget.cpp", "db/dac/PipeWidget_8cpp.html", null ],
    [ "PipeWidget.h", "d0/d15/PipeWidget_8h.html", [
      [ "PipeWidget", "d9/d4c/classPipeWidget.html", "d9/d4c/classPipeWidget" ]
    ] ]
];