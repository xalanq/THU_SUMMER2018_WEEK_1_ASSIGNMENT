var annotated_dup =
[
    [ "MainWidget", "d9/d73/classMainWidget.html", "d9/d73/classMainWidget" ],
    [ "MainWindow", "d6/d1a/classMainWindow.html", "d6/d1a/classMainWindow" ],
    [ "NewDialog", "d3/dcc/classNewDialog.html", "d3/dcc/classNewDialog" ],
    [ "PanelWidget", "d3/d3b/classPanelWidget.html", "d3/d3b/classPanelWidget" ],
    [ "PipeWidget", "d9/d4c/classPipeWidget.html", "d9/d4c/classPipeWidget" ]
];