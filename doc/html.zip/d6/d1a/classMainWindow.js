var classMainWindow =
[
    [ "MainWindow", "d6/d1a/classMainWindow.html#a8b244be8b7b7db1b08de2a2acb9409db", null ],
    [ "~MainWindow", "d6/d1a/classMainWindow.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "actionAbout", "d6/d1a/classMainWindow.html#a65e81642b7bdead8a9e2cb7446c90213", null ],
    [ "actionNew", "d6/d1a/classMainWindow.html#a21dae4d82af461609881370dac930d0c", null ],
    [ "makeCenter", "d6/d1a/classMainWindow.html#ac6f77b35e6c016dc3fb017c4221e1413", null ],
    [ "mainWidget", "d6/d1a/classMainWindow.html#acf2f9067838cc33a677aa8339ad0ac27", null ],
    [ "panelDock", "d6/d1a/classMainWindow.html#ab65dedffc61de349374eb7b6d73fe11e", null ],
    [ "panelWidget", "d6/d1a/classMainWindow.html#a1d4f30fde8a1fcda4f7008e753b28ae4", null ],
    [ "ui", "d6/d1a/classMainWindow.html#a35466a70ed47252a0191168126a352a5", null ]
];