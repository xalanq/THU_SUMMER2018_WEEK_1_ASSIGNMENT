var classPipeWidget =
[
    [ "PipeWidget", "d9/d4c/classPipeWidget.html#ac6b7d4da60ebc2f4bc2ee7cddf4e93a4", null ],
    [ "~PipeWidget", "d9/d4c/classPipeWidget.html#af846fe7a4e1ddb6e6b4c0bcb368ea207", null ],
    [ "del", "d9/d4c/classPipeWidget.html#a51bff4b4c97336b5a238fe3982285fd8", null ],
    [ "ins", "d9/d4c/classPipeWidget.html#a2732caf3ee02b26c63f4c9b272970b04", null ],
    [ "setData", "d9/d4c/classPipeWidget.html#a9d4ca41981bed4aa69c0ce18a3f43bcb", null ],
    [ "setMainWidget", "d9/d4c/classPipeWidget.html#a3a8241e5a8db153db463d10a207f6797", null ],
    [ "checked", "d9/d4c/classPipeWidget.html#a0f548545bf6c0f6b6fb7216196716ca3", null ],
    [ "id", "d9/d4c/classPipeWidget.html#a12156a3748b549777e32c1ce7bd7ebda", null ],
    [ "mw", "d9/d4c/classPipeWidget.html#a01cc96cde8e4e10ab325d3c9eca3cf52", null ],
    [ "ui", "d9/d4c/classPipeWidget.html#a23f655b59b60cd70c594656ec50b58c5", null ],
    [ "w", "d9/d4c/classPipeWidget.html#ada8b1a5a330d53f12ff06c68aaf1cf12", null ]
];