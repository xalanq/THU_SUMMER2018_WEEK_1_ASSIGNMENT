var classPanelWidget =
[
    [ "PanelWidget", "d3/d3b/classPanelWidget.html#ace0fa81a89547939801265259a526736", null ],
    [ "addWidgets", "d3/d3b/classPanelWidget.html#ac927ddf0baccaabb76f9aab045e9bd11", null ],
    [ "setMainWidget", "d3/d3b/classPanelWidget.html#a525204aaba1db4c433787905d5921ce9", null ],
    [ "slotKeyDel", "d3/d3b/classPanelWidget.html#a7aad5f83fe6016ba854de18e35e53f02", null ],
    [ "slotKeyIns", "d3/d3b/classPanelWidget.html#a993f80b7b434834792a6ba9536e52791", null ],
    [ "slotUpdateCurrentInfo", "d3/d3b/classPanelWidget.html#afd0a3e52e9650d6f50bac3a8053c1eb0", null ],
    [ "slotUpdateSelectedInfo", "d3/d3b/classPanelWidget.html#a8242fb94e255d8da396225f3419110d4", null ],
    [ "cnt", "d3/d3b/classPanelWidget.html#a905063ebb3e462c5b1715ec62c0ba8fd", null ],
    [ "mw", "d3/d3b/classPanelWidget.html#a1590417aadb15a6e4b7a33d03cdec5e4", null ],
    [ "pips", "d3/d3b/classPanelWidget.html#af136bc4a49a076ca1a210cc2c662ddbd", null ]
];