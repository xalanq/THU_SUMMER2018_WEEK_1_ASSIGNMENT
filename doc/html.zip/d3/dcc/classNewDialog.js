var classNewDialog =
[
    [ "NewDialog", "d3/dcc/classNewDialog.html#acb4da6bb60735a7a6452a038d6bcd7d8", null ],
    [ "~NewDialog", "d3/dcc/classNewDialog.html#a971b50e63d72ee512ccf6df01725afa4", null ],
    [ "accept", "d3/dcc/classNewDialog.html#ad198da5f30926d0552a2964b7e13aa1d", null ],
    [ "setData", "d3/dcc/classNewDialog.html#a67a52d246911c534720eff2b2ddb4961", null ],
    [ "slotUpdate", "d3/dcc/classNewDialog.html#af3f0c0e47e3cb8c98d503c55963b8b7c", null ],
    [ "ui", "d3/dcc/classNewDialog.html#a3a690105d41c16b6b52d2cb65fb05780", null ]
];