var searchData=
[
  ['mainwidget',['MainWidget',['../d9/d73/classMainWidget.html',1,'']]],
  ['mainwindow',['MainWindow',['../d6/d1a/classMainWindow.html',1,'']]]
];
