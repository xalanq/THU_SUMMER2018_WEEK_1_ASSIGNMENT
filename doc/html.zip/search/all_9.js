var searchData=
[
  ['n',['n',['../d9/d73/classMainWidget.html#a60af7a5f4c56b2b477270346423b1024',1,'MainWidget::n()'],['../d3/d7a/namespaceCore.html#ae031d1d8ae24740d9107ba10a94b5b2b',1,'Core::n()'],['../d3/d7a/namespaceCore.html#a61b9671e67d6422e0eec0efdb5f3d184',1,'Core::N()']]],
  ['newdialog',['NewDialog',['../d3/dcc/classNewDialog.html',1,'NewDialog'],['../d3/dcc/classNewDialog.html#acb4da6bb60735a7a6452a038d6bcd7d8',1,'NewDialog::NewDialog()']]],
  ['newdialog_2ecpp',['NewDialog.cpp',['../d6/dda/NewDialog_8cpp.html',1,'']]],
  ['newdialog_2eh',['NewDialog.h',['../d4/d87/NewDialog_8h.html',1,'']]],
  ['next',['next',['../dc/d2e/structMainWidget_1_1Pipe.html#aeb3c096630e42d625abef093530d26cc',1,'MainWidget::Pipe']]],
  ['node',['Node',['../da/d47/structMainWidget_1_1Node.html',1,'MainWidget::Node'],['../da/d47/structMainWidget_1_1Node.html#ac5d211d4b309016d256a5c7c88e7c279',1,'MainWidget::Node::Node()']]],
  ['nodes',['nodes',['../d9/d73/classMainWidget.html#a73833250b30a27e14fb991b00d895b23',1,'MainWidget']]]
];
