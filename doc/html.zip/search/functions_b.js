var searchData=
[
  ['topixel',['toPixel',['../d9/d73/classMainWidget.html#acc9146806637820bf64addc51893e6e9',1,'MainWidget::toPixel(double x)'],['../d9/d73/classMainWidget.html#a163229f5742400d0a7bc4bc907681a3b',1,'MainWidget::toPixel(const QRectF &amp;r)']]]
];
