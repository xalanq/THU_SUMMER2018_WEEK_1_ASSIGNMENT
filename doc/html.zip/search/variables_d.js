var searchData=
[
  ['ui',['ui',['../d6/d1a/classMainWindow.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow::ui()'],['../d3/dcc/classNewDialog.html#a3a690105d41c16b6b52d2cb65fb05780',1,'NewDialog::ui()'],['../d9/d4c/classPipeWidget.html#a23f655b59b60cd70c594656ec50b58c5',1,'PipeWidget::ui()']]]
];
