var searchData=
[
  ['newdialog_2ecpp',['NewDialog.cpp',['../d6/dda/NewDialog_8cpp.html',1,'']]],
  ['newdialog_2eh',['NewDialog.h',['../d4/d87/NewDialog_8h.html',1,'']]]
];
