var searchData=
[
  ['m',['M',['../d3/d7a/namespaceCore.html#a373737c505689993382c80712ee82ac4',1,'Core']]],
  ['mainwidget',['mainWidget',['../d6/d1a/classMainWindow.html#acf2f9067838cc33a677aa8339ad0ac27',1,'MainWindow']]],
  ['mat',['mat',['../d3/d7a/namespaceCore.html#a7a966bc1d24aab350fe3b5906850b211',1,'Core']]],
  ['mw',['mw',['../d3/d3b/classPanelWidget.html#a1590417aadb15a6e4b7a33d03cdec5e4',1,'PanelWidget::mw()'],['../d9/d4c/classPipeWidget.html#a01cc96cde8e4e10ab325d3c9eca3cf52',1,'PipeWidget::mw()']]]
];
