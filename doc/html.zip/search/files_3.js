var searchData=
[
  ['panelwidget_2ecpp',['PanelWidget.cpp',['../d1/d07/PanelWidget_8cpp.html',1,'']]],
  ['panelwidget_2eh',['PanelWidget.h',['../de/d42/PanelWidget_8h.html',1,'']]],
  ['pipewidget_2ecpp',['PipeWidget.cpp',['../db/dac/PipeWidget_8cpp.html',1,'']]],
  ['pipewidget_2eh',['PipeWidget.h',['../d0/d15/PipeWidget_8h.html',1,'']]]
];
