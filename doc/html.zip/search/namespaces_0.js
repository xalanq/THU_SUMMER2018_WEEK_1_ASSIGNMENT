var searchData=
[
  ['core',['Core',['../d3/d7a/namespaceCore.html',1,'']]]
];
