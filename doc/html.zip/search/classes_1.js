var searchData=
[
  ['newdialog',['NewDialog',['../d3/dcc/classNewDialog.html',1,'']]],
  ['node',['Node',['../da/d47/structMainWidget_1_1Node.html',1,'MainWidget']]]
];
