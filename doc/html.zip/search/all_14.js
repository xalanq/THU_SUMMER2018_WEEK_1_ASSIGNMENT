var searchData=
[
  ['_7emainwidget',['~MainWidget',['../d9/d73/classMainWidget.html#add21c63f8e799303a21a69da3d288c2f',1,'MainWidget']]],
  ['_7emainwindow',['~MainWindow',['../d6/d1a/classMainWindow.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]],
  ['_7enewdialog',['~NewDialog',['../d3/dcc/classNewDialog.html#a971b50e63d72ee512ccf6df01725afa4',1,'NewDialog']]],
  ['_7epipewidget',['~PipeWidget',['../d9/d4c/classPipeWidget.html#af846fe7a4e1ddb6e6b4c0bcb368ea207',1,'PipeWidget']]]
];
