var searchData=
[
  ['selected',['selected',['../dc/d2e/structMainWidget_1_1Pipe.html#afb0f725e0b50800b4a423c13ea340d12',1,'MainWidget::Pipe::selected()'],['../d9/d73/classMainWidget.html#a86e3735f8968d7210da0ea5f65c5691e',1,'MainWidget::selected()']]],
  ['setdata',['setData',['../d3/dcc/classNewDialog.html#a67a52d246911c534720eff2b2ddb4961',1,'NewDialog::setData()'],['../d9/d4c/classPipeWidget.html#a9d4ca41981bed4aa69c0ce18a3f43bcb',1,'PipeWidget::setData()']]],
  ['setmainwidget',['setMainWidget',['../d3/d3b/classPanelWidget.html#a525204aaba1db4c433787905d5921ce9',1,'PanelWidget::setMainWidget()'],['../d9/d4c/classPipeWidget.html#a3a8241e5a8db153db463d10a207f6797',1,'PipeWidget::setMainWidget()']]],
  ['signalcurrentchanged',['signalCurrentChanged',['../d9/d73/classMainWidget.html#a8a062dc1e9f3605d3b69a8e8d18eca54',1,'MainWidget']]],
  ['signalselectedchanged',['signalSelectedChanged',['../d9/d73/classMainWidget.html#a126988e51c8976596aebd5485aa3344e',1,'MainWidget']]],
  ['slotkeydel',['slotKeyDel',['../d3/d3b/classPanelWidget.html#a7aad5f83fe6016ba854de18e35e53f02',1,'PanelWidget']]],
  ['slotkeyins',['slotKeyIns',['../d3/d3b/classPanelWidget.html#a993f80b7b434834792a6ba9536e52791',1,'PanelWidget']]],
  ['slotupdate',['slotUpdate',['../d3/dcc/classNewDialog.html#af3f0c0e47e3cb8c98d503c55963b8b7c',1,'NewDialog']]],
  ['slotupdatecurrentinfo',['slotUpdateCurrentInfo',['../d3/d3b/classPanelWidget.html#afd0a3e52e9650d6f50bac3a8053c1eb0',1,'PanelWidget']]],
  ['slotupdateselectedinfo',['slotUpdateSelectedInfo',['../d3/d3b/classPanelWidget.html#a8242fb94e255d8da396225f3419110d4',1,'PanelWidget']]],
  ['speed',['speed',['../dc/d2e/structMainWidget_1_1Pipe.html#aacd112d9daa0b7b7a0063e5ea4bf0651',1,'MainWidget::Pipe::speed()'],['../d9/d73/classMainWidget.html#a0e295c70fd72d9bf39657611b30969dd',1,'MainWidget::speed()']]]
];
