var searchData=
[
  ['newdialog',['NewDialog',['../d3/dcc/classNewDialog.html#acb4da6bb60735a7a6452a038d6bcd7d8',1,'NewDialog']]],
  ['node',['Node',['../da/d47/structMainWidget_1_1Node.html#ac5d211d4b309016d256a5c7c88e7c279',1,'MainWidget::Node']]]
];
