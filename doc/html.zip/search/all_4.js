var searchData=
[
  ['getid',['getID',['../d9/d73/classMainWidget.html#a369d067aa741e17d0d10526a39bb7c54',1,'MainWidget::getID()'],['../d3/d7a/namespaceCore.html#aeda9dc53eca319811476a88117a92a66',1,'Core::getID()']]],
  ['guass',['guass',['../d3/d7a/namespaceCore.html#ae10d0c60de3d3233b1aaf936506da593',1,'Core']]]
];
