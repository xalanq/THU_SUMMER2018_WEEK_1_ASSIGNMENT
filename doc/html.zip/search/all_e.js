var searchData=
[
  ['topixel',['toPixel',['../d9/d73/classMainWidget.html#acc9146806637820bf64addc51893e6e9',1,'MainWidget::toPixel(double x)'],['../d9/d73/classMainWidget.html#a163229f5742400d0a7bc4bc907681a3b',1,'MainWidget::toPixel(const QRectF &amp;r)']]],
  ['tot',['tot',['../d9/d73/classMainWidget.html#ae7cf3bec5a96f782cba2877c9bd36fe5',1,'MainWidget::tot()'],['../d3/d7a/namespaceCore.html#a668545e27eadaacc3facfffccb86a5a2',1,'Core::tot()']]],
  ['tp',['tp',['../d3/d7a/namespaceCore.html#acff4f5dd344907347b72311135e56226',1,'Core']]]
];
