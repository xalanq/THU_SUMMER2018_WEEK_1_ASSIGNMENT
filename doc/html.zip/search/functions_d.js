var searchData=
[
  ['work',['work',['../d3/d7a/namespaceCore.html#ae7cef79d0b5a4a9e8543d673c85ee2ee',1,'Core']]]
];
