var searchData=
[
  ['selected',['selected',['../dc/d2e/structMainWidget_1_1Pipe.html#afb0f725e0b50800b4a423c13ea340d12',1,'MainWidget::Pipe::selected()'],['../d9/d73/classMainWidget.html#a86e3735f8968d7210da0ea5f65c5691e',1,'MainWidget::selected()']]],
  ['speed',['speed',['../dc/d2e/structMainWidget_1_1Pipe.html#aacd112d9daa0b7b7a0063e5ea4bf0651',1,'MainWidget::Pipe::speed()'],['../d9/d73/classMainWidget.html#a0e295c70fd72d9bf39657611b30969dd',1,'MainWidget::speed()']]]
];
