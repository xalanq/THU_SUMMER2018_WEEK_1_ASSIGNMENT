var searchData=
[
  ['tot',['tot',['../d9/d73/classMainWidget.html#ae7cf3bec5a96f782cba2877c9bd36fe5',1,'MainWidget::tot()'],['../d3/d7a/namespaceCore.html#a668545e27eadaacc3facfffccb86a5a2',1,'Core::tot()']]],
  ['tp',['tp',['../d3/d7a/namespaceCore.html#acff4f5dd344907347b72311135e56226',1,'Core']]]
];
