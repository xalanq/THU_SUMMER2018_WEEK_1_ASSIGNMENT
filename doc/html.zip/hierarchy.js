var hierarchy =
[
    [ "MainWidget::Node", "da/d47/structMainWidget_1_1Node.html", null ],
    [ "MainWidget::Pipe", "dc/d2e/structMainWidget_1_1Pipe.html", null ],
    [ "QDialog", null, [
      [ "NewDialog", "d3/dcc/classNewDialog.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "d6/d1a/classMainWindow.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "MainWidget", "d9/d73/classMainWidget.html", null ],
      [ "PanelWidget", "d3/d3b/classPanelWidget.html", null ],
      [ "PipeWidget", "d9/d4c/classPipeWidget.html", null ]
    ] ]
];