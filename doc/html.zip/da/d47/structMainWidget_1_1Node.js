var structMainWidget_1_1Node =
[
    [ "Node", "da/d47/structMainWidget_1_1Node.html#ac5d211d4b309016d256a5c7c88e7c279", null ],
    [ "rect", "da/d47/structMainWidget_1_1Node.html#a893498b4add7709d6d6cd1186b92f81e", null ],
    [ "adj", "da/d47/structMainWidget_1_1Node.html#a4f4e336fe0a117cbb12da634c79a8410", null ],
    [ "w", "da/d47/structMainWidget_1_1Node.html#af224abc23677c83080f7b15ea690fbc8", null ],
    [ "x", "da/d47/structMainWidget_1_1Node.html#acd5841f4d9e5acba30d198f8d44b2824", null ],
    [ "y", "da/d47/structMainWidget_1_1Node.html#a4aa0165ff59e4e78e2eb91d45d642a91", null ]
];